# _*_ coding : UTF-8 _*_
# 开发人员 : ChangYw
# 开发时间 : 2019/8/6 20:30
# 文件名称 : Gun.PY
# 开发工具 : PyCharm

##枪
import random
gun_list = ["M4A1", "AK47", "Kar-98K"]

class Gun:
    def __init__(self,name):
        self.name = name

    #装上弹匣
    def gun_shot(self,clip):
        self.name = clip.shot()

    #老王开枪
    def shoot(self,clip,bullet,enery_list):
        clip.show_clip(bullet)
        bullet.num -= 1
        #随机概率命中
        hit_rate = random.random()

        if self.name == gun_list[0]:
            if hit_rate >= 0.3:
                clip.show_clip(bullet)
                enery_random = random.choice(enery_list)
                enery_random.HP -= 35
                print("已命中敌人，干的漂亮！")
                if len(enery_list) == 0:
                    return False
                return True
            else:
                if bullet.num  == 0 :
                    print("游戏结束,没能击中敌人！")
                    return False
                print("尚未命中，加油。")
                return True
        elif self.name == gun_list[1]:
            if hit_rate >= 0.5:
                clip.show_clip(bullet)
                enery_random = random.choice(enery_list)
                enery_random.HP -= 45
                print("已命中敌人，干的漂亮！")
                if len(enery_list) == 0:
                    return False
                return True
            else:
                if bullet.num  == 0 :
                    print("游戏结束,没能击中敌人！")
                    return True
                print("尚未命中，加油。")
                return True
        elif self.name == gun_list[2]:
            if hit_rate >= 0.5:
                clip.show_clip(bullet)
                enery_random = random.choice(enery_list)
                enery_random.HP -= 100

                print("已命中敌人，干的漂亮！")
                if len(enery_list) == 0:
                    return False
                return True
            else:
                if bullet.num  == 0 :
                    print("游戏结束,没能击中敌人！")
                    return False
                print("尚未命中，加油。")
                return True

    #电脑开枪
    def com_shoot(self,bullet,player):
        bullet.num -= 1
        #随机概率命中
        hit_rate = random.random()
        if hit_rate >= 0.9 :
            player.HP -= 20
            print("老王被击中，剩余HP：%s"%player.HP)
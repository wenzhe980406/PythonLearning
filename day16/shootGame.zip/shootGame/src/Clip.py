# _*_ coding : UTF-8 _*_
# 开发人员 : ChangYw
# 开发时间 : 2019/8/6 20:30
# 文件名称 : Clip.PY
# 开发工具 : PyCharm
clip_num = 30

#弹匣:快速扩容弹匣
class Clip:
    def __init__(self,name):
        self.name = name
        self.num = clip_num

    #装弹
    def shot(self,bullet):
        print("已装备%s，正在装弹，子弹为%s，数量为：%d"%(self.name,bullet.name,bullet.num))

    #查看剩余子弹
    def show_clip(self,bullet):
        if bullet.num == 0 :
            print("子弹消耗完毕，没有完全消灭敌人。")
            return False
        print("子弹数量剩余：%d" % (bullet.num))
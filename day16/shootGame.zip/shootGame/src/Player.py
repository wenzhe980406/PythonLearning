# _*_ coding : UTF-8 _*_
# 开发人员 : ChangYw
# 开发时间 : 2019/8/6 20:30
# 文件名称 : Player.PY
# 开发工具 : PyCharm

#老王
class Player:
    def __init__(self,name):
        self.__name = name
        self.HP = 100


    @property
    def name(self):
        return self.__name

    @name.setter
    def name(self,name):
        self.__name = name

    #拿枪
    def get_gun(self,Gun):
        print("玩家%s拿到了枪%s"%(self.name,Gun.name))

    #开枪
    def play_shoot(self,Gun,clip,bullet,enery_list):
        if len(enery_list) > 0:
            for i in enery_list:
                if i.HP <= 0:
                    print(i.name,"电脑已被击败一个。")
                    del enery_list[enery_list.index(i)]
        else:
            print("电脑已全部被击败，游戏结束")
            return False
        return Gun.shoot(clip,bullet,enery_list)

# _*_ coding : UTF-8 _*_
# 开发人员 : ChangYw
# 开发时间 : 2019/8/6 20:31
# 文件名称 : Enery.PY
# 开发工具 : PyCharm


class Enery:
    def __init__(self):
        self.name = "电脑选手"
        self.HP = 100

    #拿枪
    def get_gun(self,gun):
        return gun.name


    # 开枪
    def play_shoot(self,gun,bullet,player):
        if player.HP == 0:
            print("您已被击败，游戏结束。")
            return False
        return gun.com_shoot(bullet,player)
# _*_ coding : UTF-8 _*_
# 开发人员 : ChangYw
# 开发时间 : 2019/8/6 20:30
# 文件名称 : Bullet.PY
# 开发工具 : PyCharm

#子弹
class Bullet:
    def __init__(self,name,num = 30):
        self.name = name
        self.num = num

    #给弹
    def tobullet(self):
        if self.name == '7.62mm' :
            print("已检测到%s子弹，正在准备装弹%d颗"%(self.name,self.num))
            return [self.name * self.num]
        elif self.name == '5.56mm' :
            print("已检测到%s子弹，正在准备装弹%d颗"%(self.name,self.num))
            return [self.name * self.num]